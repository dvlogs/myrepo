from flask import Flask
import random


# a = input('Enter Password Range (3 to 6): ') 
a= '4'
if a == '3':
    Strpass = random.randint(100,999)
    print('Your Password Is',Strpass)
elif a == '4':
    Strpass = random.randint(1000,9999)
    print('Your Password Is',Strpass)
elif a == '5':
    Strpass = random.randint(10000,99999)
    print('Your Password Is',Strpass)
elif a == '6':
    Strpass = random.randint(100000,99999)
    print('Your Password Is',Strpass)
else:
    print('password range not valid !')
    exit()



from tkinter import *
from os import *
import base64
window = Tk()
window.title('secure password page')

passwd = StringVar()
Label(window, text='Enter Your Password', bd=3,width=100, bg='green').pack()
Entry(window, bd=3, width=117, textvariable=passwd, relief=SUNKEN).pack()

def convert():
    message = passwd.get()
    encode = message.encode('ascii')
    base64_bytes = base64.b64encode(encode)
    encrypt = base64_bytes.decode('ascii')
    passwdCD.set(encrypt)

Button(window, width=100, text='Generate Password', command=convert, bd=3, bg='blue', fg='white').pack()

passwdCD = StringVar()
Entry(window, bd=3, width=117, textvariable=passwdCD, relief=SUNKEN).pack()

def convert_rev():
    message = passwd.get()
    encode = message.encode('ascii')
    base64_bytes = base64.b64decode(encode)
    encrypt = base64_bytes.decode('ascii')
    return encrypt
    

passwdCn = StringVar()
Label(window).pack(pady=20)
de= Label(window, text='Convert Password to word', bd=3,width=100, bg='green').pack()
Entry(window, bd=3, width=117, textvariable=passwdCn, relief=SUNKEN).pack()
def convert_rev_cv():
    message = passwdCn.get()
    encode = message.encode('ascii')
    base64_bytes = base64.b64decode(encode)
    encrypt = base64_bytes.decode('ascii')
    return encrypt
def con():
    pw = convert_rev_cv()
    passwdsw.set(pw)
Button(window, width=100, text='Convert Password', command=con, bd=3, bg='blue', fg='white').pack()

passwdsw = StringVar()
Entry(window, bd=3, width=117, textvariable=passwdsw, relief=SUNKEN).pack()


window.mainloop()


