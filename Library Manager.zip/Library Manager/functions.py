import sqlite3
conn = sqlite3.connect('sql_2.db') # Complete

def create_table(): # Complete
    conn.execute('create table if not exists bookM(sno INTEGER PRIMARY KEY AutoIncrement, book VARCHAR(100), position VARCHAR(15))')
    conn.commit()
def add_book(book, position): # Complete
    if position == True:
        conn.execute(f'INSERT INTO bookM(book, position) values("{book}", "Available")')
        conn.commit()
    elif position == False:
        conn.execute(f'INSERT INTO bookM(book, position) values("{book}", "Unavailable")')
        conn.commit()
    print('added - > book ', book, position)

def unavailable(book): # Complete
    conn.execute(f'UPDATE bookM set position="Unavailable" where book="{book}"')
    conn.commit()
    print('position changed -> unavailable,  book',book)

def available(book): # Complete
    conn.execute(f'UPDATE bookM set position="Available" where book="{book}"')
    conn.commit()
    print('position changed -> available,  book',book)

def find_book(book): # Complete
    listOfData = conn.execute(f'SELECT * FROM bookM WHERE book="{book}"')
    return listOfData.fetchall()

def find_available_books(): # Complete
    AvaBooks = conn.execute('SELECT * FROM bookM where position="Available"')
    l = AvaBooks.fetchall()
    return l

def find_unavailable_books(): # Complete
    unAvaBooks = conn.execute('SELECT * FROM bookM where position="Unavailable"')
    l = unAvaBooks.fetchall()
    return l

def delete_book(book): # Complete
    conn.execute(f'delete from bookM where book="{book}"')
    conn.commit()
    print('deleted -> ',book)


def show_all_books(): # Complete
    a = conn.execute('select * from bookM')
    data = a.fetchall()
    return data
