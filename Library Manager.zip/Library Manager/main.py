from tkinter import *

# @ <!-- SQLITE3 --> <!-- Connections and functions --> ========================= D V ========================= @ @ #
# @ <!-- SQLITE3 --> <!-- Connections and functions --> ========================= D V ========================= @ @ #
# @ <!-- SQLITE3 --> <!-- Connections and functions --> ========================= D V ========================= @ @ #


import sqlite3
conn = sqlite3.connect('sql_2.db') # Complete
def create_table(): # Complete
    conn.execute('create table bookM(sno INTEGER PRIMARY KEY AutoIncrement, book VARCHAR(100), position VARCHAR(15))')
    conn.commit()

def add_book(book, position): # Complete
    if position == True:
        conn.execute(f'INSERT INTO bookM(book, position) values("{book}", "Available")')
        conn.commit()
    elif position == False:
        conn.execute(f'INSERT INTO bookM(book, position) values("{book}", "Unavailable")')
        conn.commit()
    print('added - > book ', book, position)
def unavailable(book): # Complete
    conn.execute(f'UPDATE bookM set position="Unavailable" where book="{book}"')
    conn.commit()
    print('position changed -> unavailable,  book',book)

def available(book): # Complete
    conn.execute(f'UPDATE bookM set position="Available" where book="{book}"')
    conn.commit()
    print('position changed -> available,  book',book)

def find_book(book): # Complete
    listOfData = conn.execute(f'SELECT * FROM bookM WHERE book="{book}"')
    return listOfData.fetchall()

def find_available_books(): # Complete
    AvaBooks = conn.execute('SELECT * FROM bookM where position="Available"')
    l = AvaBooks.fetchall()
    return l

def find_unavailable_books(): # Complete
    unAvaBooks = conn.execute('SELECT * FROM bookM where position="Unavailable"')
    l = unAvaBooks.fetchall()
    return l

def delete_book(book): # Complete
    conn.execute(f'delete from bookM where book="{book}"')
    conn.commit()
    print('deleted -> ',book)

add_book(f'A005', True)

def show_all_books(): # Complete
    a = conn.execute('select * from bookM')
    data = a.fetchall()
    return data


# @ <!-- SQLITE3 --> <!-- Connections and functions --> ========================= D V ========================= @ @ #
# @ <!-- SQLITE3 --> <!-- Connections and functions --> ========================= D V ========================= @ @ # 
# @ <!-- SQLITE3 --> <!-- Connections and functions --> ========================= D V ========================= @ @ # 



'''
function list:

add_book(book='A102', position=True) # This Function is add book
delete_book(book='A101') #  this function is delete book for forever
show_all_books() # returns a list of all books (available, unavailable)
find_unavailable_books() # returns a list of all unavailable books
find_available_books() # returns a list of all available books
find_book('A512') # returns this list [book sno number, book name, book position (available or unavailable)]
available('A514') # change the position of book (unavailable to available)
unavailable('A514') # change the position of book (available to unavailable)

database: sql_1.db

'''

window = Tk()
window.title('Library Manager')
s_height = window.winfo_screenheight()
s_width = window.winfo_screenwidth()
print('Width',s_width,'\t','Height',s_height)
# Colors #
lightYellow = '#F9F774'
darkYellow = '#CF8400'
white = 'white'
commanC = '#008800'
tnr = 'times new romen'
f12 = '12'
f10 = '10'
b = 'bold'
gold = 'gold'
sk = SUNKEN
gr = GROOVE
# Colors #


class Table:
    def __init__(self, window):
        listOfData = show_all_books()
        le = []
        for i in range(0,len(listOfData)):
            le.append((listOfData[i][0], listOfData[i][1], listOfData[i][2]))
        T_row = len(le)
        T_col = len(le[0])
        t1 = LabelFrame(window, text='Book List', fg='gold', font=('times new romen', 12, 'bold'), bd=4, relief=GROOVE,bg='#008800')
        t1.place(x=0, y=175)
        for i in range(T_row):
            for j in range(T_col):
                self.e = Entry(t1, width=29, fg='black', bd=2, bg=lightYellow, font=(tnr, 21, b))
                self.e.grid(row=i, column=j)
                self.e.insert(END, le[i][j])

def Tabler(list):
    listOfData = list
    le = []
    for i in range(0,len(listOfData)):
        le.append((listOfData[i][0], listOfData[i][1], listOfData[i][2]))
    T_row = len(le)
    T_col = len(le[0])
    t1 = LabelFrame(window, text='Book List', fg='gold', font=('times new romen', 12, 'bold'), bd=4, relief=GROOVE,bg='#008800')
    t1.place(x=0, y=175)
    for i in range(T_row):
        for j in range(T_col):
            e = Entry(t1, width=29, fg='black', bd=2, bg=lightYellow, font=(tnr, 21, b))
            e.grid(row=i, column=j)
            e.insert(END, le[i][j])

Label(window,border=4,fg='yellow',bg='green',text='Library Manager',font=(tnr,22,b), relief=GROOVE).place(relwidth=1)



# ==================== > Add Books < ==================== # 
l2 = LabelFrame(window,text='Add Book / Available / Show Table', fg='gold', font=('times new romen', 10, 'bold'), bd=4, relief=GROOVE,bg='#008800')
l2.place(x=0,y=44,relwidth=1)
book_VAR = StringVar()
def b_add_FUNC():
    clear()
    if book_VAR.get() != '':
        add_book(book=book_VAR.get(), position=True)
        if book_VAR.get() != '':
            Table(window)
    book_VAR.set('')
    show()

Label(l2, text='Book Name ',font=('arial',12 ,'bold'),fg='white',bg='#008800').grid(row=0,column=0,padx=2,pady=3)
Entry(l2,textvariable=book_VAR,bd=4,width=20,font='arial 12',fg=darkYellow,relief=SUNKEN).grid(row=0,column=1,padx=2,pady=3)
Button(l2,command=b_add_FUNC,text='ADD', width=20,fg='black',bd=4,font='arial 12 bold').grid(row=0,column=2,padx=20,pady=3)
# ==================== > Add Books < ==================== # 



# ==================== > delete Books < ==================== # 
l1 = LabelFrame(window,text='Delete Book / Unavailable / Clear Table', fg='gold', font=('times new romen', 10, 'bold'), bd=4, relief=GROOVE,bg='#008800')
l1.place(x=0,y=110,relwidth=1)
def b_del_FUNC():
    clear()
    if book_VAR.get() != '':
        try:
            delete_book(book=book_VAR.get())
        except:
            book_VAR.set(value='@ Ths Book Does not Exists @')
        if book_VAR.get() != '':
            Table(window)
    show()
    book_VAR.set('')

Label(l1, text='\t \t \t \t',font=('arial',12 ,'bold'),fg='white',bg='#008800').grid(row=0,column=0,padx=2,pady=3)
Label(l1, text='\t \t \t \t',font=('arial',12 ,'bold'),fg='white',bg='#008800').grid(row=0,column=0,padx=2,pady=3)
Button(l1,command=b_del_FUNC,text='DELETE', width=20,fg='black',bd=4,font='arial 12 bold').grid(row=0,column=2,padx=20,pady=3)
# ==================== > delete Books < ==================== # 

def fab():
        clear()
        fe = find_available_books()
        le = fe
        T_row = len(le)
        T_col = len(le[0])
        t1 = LabelFrame(window, text='Book List', fg='gold', font=('times new romen', 12, 'bold'), bd=4, relief=GROOVE,bg='#008800')
        t1.place(x=0, y=175)
        for i in range(T_row):
            for j in range(T_col):
                e = Entry(t1, width=29, fg='black', bd=2, bg=lightYellow, font=(tnr, 21, b))
                e.grid(row=i, column=j)
                e.insert(END, le[i][j])



def sun():
    clear()
    Tabler(list=find_unavailable_books())
Button(l1,text='ShowUnavailables',command=sun, width=20,fg='black',bd=4,font='arial 12 bold').grid(row=0,column=5,padx=20,pady=3)

def sav():
    clear()
    Tabler(find_available_books())
Button(l2,text='ShowAvailables',command=sav, width=20,fg='black',bd=4,font='arial 12 bold').grid(row=0,column=5,padx=20,pady=3)


# clear / show #
def clear():
    lp = LabelFrame(window, fg='white', font=('times new romen', 10, 'bold'), bd=0, width=1400,height=10000)
    lp.place(x=0, y=175)
def show():
    clear()
    Table(window)

Button(l1,command=clear,text='Clear Table', width=20,fg='black',bd=4,font='arial 12 bold').grid(row=0,column=4,padx=20,pady=3)
Button(l2,command=show,text='Show  Table', width=20,fg='black',bd=4,font='arial 12 bold').grid(row=0,column=4,padx=20,pady=3)
# clear / show #
def una():
    unavailable(book=book_VAR.get())
    clear()
    book_VAR.set('')
    show()
Button(l1,command=una,text='Unavailable', width=20,fg='black',bd=4,font='arial 12 bold').grid(row=0,column=3,padx=20,pady=3)

# available #
def ava():
    available(book=book_VAR.get())
    clear()
    book_VAR.set('')
    show()
Button(l2,command=ava,text='Available', width=20,fg='black',bd=4,font='arial 12 bold').grid(row=0,column=3,padx=20,pady=3)

# available #


show()
window.mainloop()