import sqlite3
conn = sqlite3.connect('sql_2.db')

conn.execute('create table if not exists bookM(sno INTEGER PRIMARY KEY AutoIncrement, book VARCHAR(100), position VARCHAR(15))')
conn.commit()

conn.close()