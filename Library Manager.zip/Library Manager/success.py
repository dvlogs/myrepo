listOfData = show_all_books()
le = []
for i in range(0,len(listOfData)):
    le.append((listOfData[i].sno, listOfData[i].book, listOfData[i].position))
print(le)
T_row = len(le)
T_col = len(le[0])
class Table:
    def __init__(self, window):
        for i in range(T_row):
            for j in range(T_col):
                self.e = Entry(window, width=22, fg='blue', font=(tnr, f12, b))
                self.e.grid(row=i, column=j)
                self.e.insert(END, le[i][j])